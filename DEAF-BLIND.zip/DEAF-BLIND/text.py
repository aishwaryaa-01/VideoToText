import nltk
from flask import Flask, render_template, request
from youtube_transcript_api import YouTubeTranscriptApi
from nltk.tokenize import sent_tokenize, word_tokenize
from nltk.corpus import stopwords
from collections import defaultdict
import string

# Initialize Flask app
app = Flask(__name__)

# Download necessary NLTK resources
nltk.download('punkt_tab')
nltk.download('stopwords')

# Function to fetch transcript from YouTube
def get_youtube_transcript(video_url):
    try:
        # Extract video ID from URL
        video_id = video_url.split('v=')[1].split('&')[0]
        transcript_data = YouTubeTranscriptApi.get_transcript(video_id)
        
        # Combine transcript into a single string
        transcript = " ".join([item['text'] for item in transcript_data])
        return transcript, transcript_data  # Return both full transcript and data for further processing
    except Exception as e:
        return str(e), None

# Function to preprocess the transcript
def preprocess_text(text):
    sentences = sent_tokenize(text)
    stop_words = set(stopwords.words("english"))
    punctuation = set(string.punctuation)
    processed_sentences = []
    
    for sentence in sentences:
        words = word_tokenize(sentence.lower())
        words = [word for word in words if word not in stop_words and word not in punctuation]
        processed_sentences.append((sentence, words))
    
    return processed_sentences

# Function to score sentences based on word frequency
def score_sentences(processed_sentences):
    word_freq = defaultdict(int)
    for _, words in processed_sentences:
        for word in words:
            word_freq[word] += 1
    
    sentence_scores = {}
    for sentence, words in processed_sentences:
        for word in words:
            if word in word_freq:
                sentence_scores[sentence] = sentence_scores.get(sentence, 0) + word_freq[word]
    
    return sentence_scores

# Function to generate the summary
def generate_summary(sentence_scores, num_sentences=5):
    sorted_sentences = sorted(sentence_scores.items(), key=lambda x: x[1], reverse=True)
    top_sentences = [sentence for sentence, _ in sorted_sentences[:num_sentences]]
    return "\n".join(top_sentences)

# Function to summarize the transcript
def summarize_transcript(video_url, num_sentences=5):
    transcript, transcript_data = get_youtube_transcript(video_url)
    if 'An error occurred' in transcript:
        return transcript, None  # Return error message if transcript fetch fails
    
    # Preprocess the transcript
    processed_sentences = preprocess_text(transcript)
    
    # Score the sentences
    sentence_scores = score_sentences(processed_sentences)
    
    # Generate the summary
    summary = generate_summary(sentence_scores, num_sentences=num_sentences)
    return transcript, summary

# Route to render the input form and handle summarization
@app.route('/', methods=['GET', 'POST'])
def index():
    original_transcript = ""
    summary = ""
    if request.method == 'POST':
        video_url = request.form['video_url']
        num_sentences = int(request.form['num_sentences'])
        original_transcript, summary = summarize_transcript(video_url, num_sentences)
    
    return render_template('index.html', original_transcript=original_transcript, summary=summary)

if __name__ == '__main__':
    app.run(debug=True)
